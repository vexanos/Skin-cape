package dev.skincape;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.blaze3d.platform.NativeImage;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.resources.ResourceLocation;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

public final class SkinCapeManager {
    public static class Cfg {
        public String skin = "";
        public String cape = "";
        public String model = "auto"; // auto | slim | wide
        public boolean enabled = true;
    }

    public static Cfg cfg = new Cfg();
    public static String status = "";

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static ResourceLocation skinTex, capeTex;
    private static boolean dirty = true;
    private static int counter = 0;

    public static Path folder() {
        Path p = FabricLoader.getInstance().getGameDir().resolve("skincape");
        try { Files.createDirectories(p); } catch (IOException ignored) {}
        return p;
    }

    private static Path cfgFile() {
        return FabricLoader.getInstance().getConfigDir().resolve("skincape.json");
    }

    public static void load() {
        try {
            if (Files.exists(cfgFile())) {
                try (Reader r = Files.newBufferedReader(cfgFile())) {
                    Cfg c = GSON.fromJson(r, Cfg.class);
                    if (c != null) cfg = c;
                }
            }
        } catch (Exception e) {
            status = "Config load failed: " + e.getMessage();
        }
        folder();
        dirty = true;
    }

    public static void save() {
        try (Writer w = Files.newBufferedWriter(cfgFile())) {
            GSON.toJson(cfg, w);
        } catch (Exception e) {
            status = "Config save failed: " + e.getMessage();
        }
    }

    public static void markDirty() { dirty = true; }

    public static List<String> listPngs() {
        List<String> out = new ArrayList<>();
        try (Stream<Path> s = Files.list(folder())) {
            s.filter(p -> p.getFileName().toString().toLowerCase().endsWith(".png"))
                    .sorted(Comparator.comparing(p -> p.getFileName().toString().toLowerCase()))
                    .forEach(p -> out.add(p.getFileName().toString()));
        } catch (IOException ignored) {}
        return out;
    }

    /** Called from the render thread (mixin), so texture upload is safe here. */
    public static PlayerSkin apply(PlayerSkin orig) {
        if (dirty) reload();
        if (!cfg.enabled || (skinTex == null && capeTex == null && "auto".equals(cfg.model))) return orig;

        PlayerSkin.Model model = orig.model();
        if ("slim".equals(cfg.model)) model = PlayerSkin.Model.SLIM;
        else if ("wide".equals(cfg.model)) model = PlayerSkin.Model.WIDE;

        ResourceLocation cape = capeTex != null ? capeTex : orig.capeTexture();
        ResourceLocation elytra = capeTex != null ? capeTex : orig.elytraTexture();
        return new PlayerSkin(skinTex != null ? skinTex : orig.texture(), orig.textureUrl(),
                cape, elytra, model, orig.secure());
    }

    private static void reload() {
        dirty = false;
        var tm = Minecraft.getInstance().getTextureManager();
        if (skinTex != null) tm.release(skinTex);
        if (capeTex != null) tm.release(capeTex);
        skinTex = null;
        capeTex = null;
        if (!cfg.enabled) return;
        skinTex = loadTexture(cfg.skin, true);
        capeTex = loadTexture(cfg.cape, false);
    }

    private static ResourceLocation loadTexture(String path, boolean isSkin) {
        if (path == null || path.isBlank()) return null;
        try {
            Path p = Path.of(path.trim());
            if (!p.isAbsolute()) p = folder().resolve(p);
            NativeImage img;
            try (InputStream in = Files.newInputStream(p)) {
                img = NativeImage.read(in);
            }
            if (isSkin) img = fixSkin(img);
            ResourceLocation rl = ResourceLocation.fromNamespaceAndPath("skincape",
                    (isSkin ? "skin_" : "cape_") + (counter++));
            Minecraft.getInstance().getTextureManager().register(rl, new DynamicTexture(img));
            status = "Applied: " + p.getFileName();
            return rl;
        } catch (Exception e) {
            status = (isSkin ? "Skin" : "Cape") + " error: " + e.getMessage();
            return null;
        }
    }

    private static NativeImage fixSkin(NativeImage img) throws IOException {
        int w = img.getWidth(), h = img.getHeight();
        if (w == 64 && h == 64) return img;
        if (w == 64 && h == 32) { // old format -> 64x64
            NativeImage n = new NativeImage(64, 64, true);
            for (int x = 0; x < 64; x++)
                for (int y = 0; y < 32; y++)
                    n.setPixelRGBA(x, y, img.getPixelRGBA(x, y));
            for (int x = 0; x < 16; x++)
                for (int y = 0; y < 16; y++) {
                    n.setPixelRGBA(16 + x, 48 + y, img.getPixelRGBA(x, 16 + y));      // left leg
                    n.setPixelRGBA(32 + x, 48 + y, img.getPixelRGBA(40 + x, 16 + y)); // left arm
                }
            img.close();
            return n;
        }
        throw new IOException("Skin must be 64x64 (or 64x32), got " + w + "x" + h);
    }
}
