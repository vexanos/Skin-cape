package dev.skincape;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

public class SkinCapeClient implements ClientModInitializer {
    public static KeyMapping OPEN_KEY;

    @Override
    public void onInitializeClient() {
        SkinCapeManager.load();
        // Customizable: Options > Controls > Key Binds > "Skin & Cape"
        OPEN_KEY = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.skincape.open", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, "category.skincape"));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (OPEN_KEY.consumeClick()) {
                if (mc.screen == null) mc.setScreen(new SkinCapeScreen(null));
            }
        });
    }
}
