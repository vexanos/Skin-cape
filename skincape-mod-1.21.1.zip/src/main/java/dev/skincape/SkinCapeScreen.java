package dev.skincape;

import net.minecraft.Util;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

public class SkinCapeScreen extends Screen {
    private final Screen parent;
    private EditBox skinBox, capeBox;
    private Button modelBtn, enabledBtn;

    public SkinCapeScreen(Screen parent) {
        super(Component.literal("Skin & Cape"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        var cfg = SkinCapeManager.cfg;

        skinBox = new EditBox(this.font, cx - 125, 55, 200, 20, Component.literal("Skin"));
        skinBox.setMaxLength(512);
        skinBox.setValue(cfg.skin);
        addRenderableWidget(skinBox);
        addRenderableWidget(Button.builder(Component.literal("<"), b -> cycle(skinBox, -1)).bounds(cx + 80, 55, 22, 20).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> cycle(skinBox, 1)).bounds(cx + 105, 55, 22, 20).build());

        capeBox = new EditBox(this.font, cx - 125, 100, 200, 20, Component.literal("Cape"));
        capeBox.setMaxLength(512);
        capeBox.setValue(cfg.cape);
        addRenderableWidget(capeBox);
        addRenderableWidget(Button.builder(Component.literal("<"), b -> cycle(capeBox, -1)).bounds(cx + 80, 100, 22, 20).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> cycle(capeBox, 1)).bounds(cx + 105, 100, 22, 20).build());

        modelBtn = addRenderableWidget(Button.builder(modelLabel(), b -> {
            cfg.model = switch (cfg.model) {
                case "auto" -> "slim";
                case "slim" -> "wide";
                default -> "auto";
            };
            b.setMessage(modelLabel());
        }).bounds(cx - 125, 130, 250, 20).build());

        enabledBtn = addRenderableWidget(Button.builder(enabledLabel(), b -> {
            cfg.enabled = !cfg.enabled;
            b.setMessage(enabledLabel());
        }).bounds(cx - 125, 155, 250, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Apply"), b -> applyNow())
                .bounds(cx - 125, 185, 122, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Reset (remove skin/cape)"), b -> {
            skinBox.setValue("");
            capeBox.setValue("");
            applyNow();
        }).bounds(cx + 3, 185, 122, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Open skincape folder"), b -> {
            try { Util.getPlatform().openFile(SkinCapeManager.folder().toFile()); }
            catch (Throwable t) { SkinCapeManager.status = "Folder: " + SkinCapeManager.folder(); }
        }).bounds(cx - 125, 210, 250, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(cx - 125, 235, 250, 20).build());
    }

    private Component modelLabel() {
        return Component.literal("Arm model: " + SkinCapeManager.cfg.model.toUpperCase() + " (click to change)");
    }

    private Component enabledLabel() {
        return Component.literal("Mod: " + (SkinCapeManager.cfg.enabled ? "ON" : "OFF"));
    }

    private void cycle(EditBox box, int dir) {
        List<String> files = SkinCapeManager.listPngs();
        if (files.isEmpty()) {
            SkinCapeManager.status = "No .png files in skincape folder";
            return;
        }
        int i = files.indexOf(box.getValue());
        i = i < 0 ? (dir > 0 ? 0 : files.size() - 1) : Math.floorMod(i + dir, files.size());
        box.setValue(files.get(i));
    }

    private void applyNow() {
        var cfg = SkinCapeManager.cfg;
        cfg.skin = skinBox.getValue().trim();
        cfg.cape = capeBox.getValue().trim();
        SkinCapeManager.save();
        SkinCapeManager.markDirty();
        SkinCapeManager.status = "Saved. Skin/cape will refresh now.";
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        super.render(g, mouseX, mouseY, delta);
        int cx = this.width / 2;
        g.drawCenteredString(this.font, this.title, cx, 15, 0xFFFFFF);
        g.drawCenteredString(this.font, "Put .png files in the skincape folder, or type a full path", cx, 30, 0xAAAAAA);
        g.drawString(this.font, "Skin (64x64 png)", cx - 125, 45, 0xFFFFFF);
        g.drawString(this.font, "Cape (64x32 png)", cx - 125, 90, 0xFFFFFF);
        g.drawCenteredString(this.font, SkinCapeManager.status, cx, 262, 0x55FF55);
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }
}
