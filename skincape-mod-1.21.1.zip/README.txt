Skin & Cape Changer (Fabric, client-side)
- Key: K (change in Options > Controls > Key Binds > "Skin & Cape")
- Put your 64x64 skin png and 64x32 cape png in  <.minecraft>/skincape/
- Open GUI, pick file with < > or type path, press Apply.
- Works on cracked/offline accounts. Only YOU see it (client-side).
